FB_IMPL_MSG(UTL, 1, utl_trusted_switch, -901, "00", "000", "Switches trusted_user and trusted_role are not supported from command line")
